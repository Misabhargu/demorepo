function Singlereview()
{
    return(
        <>
        <h1>Single Review</h1>
        </>
    )
}

export default Singlereview;